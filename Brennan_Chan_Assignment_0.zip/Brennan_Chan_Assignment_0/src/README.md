resources used:
* I followed the linked section videos for guidance on some of the JavaScript
* https://www.w3schools.com/java/ref_math_acos.asp for use of Math.acos()
* https://developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D/clearRect for clearing the drawings
* https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input for inputs
* https://developer.mozilla.org/en-US/docs/Web/HTML/Element/select for selections
* magnitude, normalize, cross, and area was done using my class notes.
* I used google for conversion of rad to degrees because I forgot.
* I also googled how to get a sqrt function with the Math methods since I wasn't sure how it worked in JavaScript
